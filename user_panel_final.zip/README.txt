
EALA80VIP - User Panel Demo (mobile-first)
------------------------------------------

Files included:
- index.html
- style.css
- script.js
- assets/  (svg icon files)

Usage:
1. Unzip the package to a folder.
2. Confirm the folder structure is like:
   index.html
   style.css
   script.js
   assets/
3. Deploy to Netlify: Site -> Deploys -> 'Drag & drop your site folder here' (upload the folder or a zip of the folder).
   Ensure index.html is at the root of the uploaded folder.
4. Open the published URL. This is a demo front-end. Replace product images or text inside assets/ as needed.

Notes:
- BNP and VIP progression are simulated in script.js for demo purposes.
- For real data, integrate backend APIs and update script.js accordingly.
