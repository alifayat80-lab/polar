
document.addEventListener('DOMContentLoaded', function(){
  const state = { username: 'EALA80VIP_User', balance: '0.00', vip: 1, bnpIndex: 1 };
  document.getElementById('uname').textContent = state.username;
  document.getElementById('balance').textContent = 'USDT: ' + state.balance;
  document.getElementById('vipBadge').textContent = 'VIP' + state.vip;
  document.getElementById('bnpValue').textContent = 'BRT-' + state.bnpIndex;

  setInterval(()=>{
    state.bnpIndex = state.bnpIndex === 3 ? 1 : state.bnpIndex + 1;
    document.getElementById('bnpValue').textContent = 'BRT-' + state.bnpIndex;
  }, 8000);

  document.querySelectorAll('.vipcard').forEach((card, idx) => {
    const submitBtn = card.querySelector('.submit');
    submitBtn.addEventListener('click', ()=>{
      const targetVip = idx + 1;
      card.style.opacity = '0.75';
      card.style.transform = 'scale(0.99)';
      state.vip = targetVip;
      document.getElementById('vipBadge').textContent = 'VIP' + state.vip;
      alert(card.getAttribute('data-name') + ' tasks submitted. VIP now: VIP' + state.vip);
    });
  });

  document.getElementById('depositBtn').addEventListener('click', ()=>{
    alert('Deposit clicked — admin address will be set in real system.');
  });
  document.getElementById('withdrawBtn').addEventListener('click', ()=>{
    alert('Withdraw clicked — demo only.');
  });
});
